package com.example.momsee.ChildLogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.momsee.R;

public class ChildLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_login);
    }
}
