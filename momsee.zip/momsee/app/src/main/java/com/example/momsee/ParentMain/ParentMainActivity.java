package com.example.momsee.ParentMain;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.momsee.R;

public class ParentMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_main);
    }
}
